# Databricks notebook source
# MAGIC %md
# MAGIC # Cuaderno ingesta de datos 
# MAGIC
# MAGIC En este cuaderno traeremos la informaciòn de datos abiertos

# COMMAND ----------

# Paso 1: Descargar los datos con requests y leerlos en pandas
import requests
import pandas as pd
from io import StringIO
from pyspark.sql import SparkSession

spark = SparkSession.builder.getOrCreate()

url_secop = "https://www.datos.gov.co/resource/rpmr-utcd.csv"
url_men = "https://www.datos.gov.co/resource/nudc-7mev.csv"

# Descargar contenido
response_secop = requests.get(url_secop)
response_men = requests.get(url_men)

# Convertir contenido a pandas usando StringIO
df_secop_pd = pd.read_csv(StringIO(response_secop.text))
df_men_pd = pd.read_csv(StringIO(response_men.text))

# Convertir pandas a Spark
df_secop = spark.createDataFrame(df_secop_pd)
df_men = spark.createDataFrame(df_men_pd)

# Mostrar en Databricks
display(df_secop)
display(df_men)
 
 

# COMMAND ----------

display(df_secop_pd.head())


# COMMAND ----------

display(df_men_pd.head())

# COMMAND ----------


# Celda 2: Guardar los DataFrames como tablas Delta
# La función .saveAsTable() guarda los datos y registra la tabla en el Unity Catalog.
# El modo "overwrite" reemplaza la tabla si ya existe, ideal para actualizaciones.
df_secop.write.format("delta").mode("overwrite").saveAsTable("main.diplomado_datos.secop")
df_men.write.format("delta").mode("overwrite").saveAsTable("main.diplomado_datos.men_estadisticas")

print("¡Tablas guardadas exitosamente en el catálogo 'main', esquema 'diplomado_datos'!")

# COMMAND ----------

import requests
import pandas as pd
from io import StringIO
from pyspark.sql import SparkSession
from pyspark.sql.functions import expr

# Inicializar Spark
spark = SparkSession.builder.getOrCreate()

# Configuración
base_url = "https://www.datos.gov.co/resource/rpmr-utcd.csv"
limit = 100000
total_registros = 16000000
max_iter = total_registros // limit

# Obtener esquema de la tabla destino
target_schema = spark.table("main.diplomado_datos.secop").schema

# Descarga por lotes
for i in range(max_iter):
    offset = i * limit
    print(f"⏳ Iteración {i+1}/{max_iter} — Offset: {offset}")

    # Descargar datos
    url = f"{base_url}?$limit={limit}&$offset={offset}"
    response = requests.get(url)

    if response.status_code != 200:
        print(f"❌ Error al descargar en offset {offset}. Código: {response.status_code}")
        break

    if len(response.text.strip()) == 0:
        print("✅ No hay más datos disponibles.")
        break

    # Leer CSV en pandas con todas las columnas como texto
    df_pd = pd.read_csv(StringIO(response.text), delimiter=",", header=0, dtype=str, low_memory=False)

    if df_pd.empty:
        print("✅ Descarga terminada: datos vacíos.")
        break

    # Convertir pandas a Spark
    df_spark = spark.createDataFrame(df_pd)

    # Alinear tipos usando try_cast para evitar errores de conversión
    df_aligned = df_spark.select([
        expr(f"try_cast(`{field.name}` AS {field.dataType.simpleString()})").alias(field.name)
        for field in target_schema.fields if field.name in df_spark.columns
    ])

    # Guardar lote en tabla Delta
    df_aligned.write.format("delta") \
        .mode("append") \
        .option("mergeSchema", "true") \
        .saveAsTable("main.diplomado_datos.secop")

    print(f"✅ Guardados {df_pd.shape[0]} registros. Total acumulado: {(i+1)*limit}")

print("🎉 Proceso completado.")


# COMMAND ----------

import requests
import pandas as pd
import time
from io import StringIO
from pyspark.sql import SparkSession
from pyspark.sql.functions import expr

# Inicializar Spark
spark = SparkSession.builder.getOrCreate()

# Configuración
base_url = "https://www.datos.gov.co/resource/rpmr-utcd.csv"
limit = 100000
total_registros = 16000000
max_iter = total_registros // limit
max_retries = 5
retry_delay = 5  # segundos

# Obtener esquema de la tabla destino
target_schema = spark.table("main.diplomado_datos.secop").schema

# Descarga por lotes con tolerancia a errores
for i in range(max_iter):
    offset = i * limit
    print(f"⏳ Iteración {i+1}/{max_iter} — Offset: {offset}")
    
    success = False
    attempts = 0
    
    while not success and attempts < max_retries:
        try:
            url = f"{base_url}?$limit={limit}&$offset={offset}"
            response = requests.get(url)

            if response.status_code == 200 and response.text.strip():
                df_pd = pd.read_csv(StringIO(response.text), delimiter=",", header=0, dtype=str, low_memory=False)

                if df_pd.empty:
                    print(f"✅ Datos vacíos en offset {offset}. Se omite lote.")
                    break

                # Convertir a Spark
                df_spark = spark.createDataFrame(df_pd)

                # Alinear tipos usando try_cast
                df_aligned = df_spark.select([
                    expr(f"try_cast(`{field.name}` AS {field.dataType.simpleString()})").alias(field.name)
                    for field in target_schema.fields if field.name in df_spark.columns
                ])

                # Guardar lote
                df_aligned.write.format("delta") \
                    .mode("append") \
                    .option("mergeSchema", "true") \
                    .saveAsTable("main.diplomado_datos.secop")

                print(f"✅ Guardados {df_pd.shape[0]} registros.")
                success = True

            else:
                print(f"⚠️ Error HTTP {response.status_code} en offset {offset}. Reintentando...")
                attempts += 1
                time.sleep(retry_delay)

        except Exception as e:
            print(f"⚠️ Excepción en offset {offset}: {e}. Reintentando...")
            attempts += 1
            time.sleep(retry_delay)

    if not success:
        print(f"❌ Fallo permanente en offset {offset} después de {max_retries} intentos. Se omite este lote.")

print("🎉 Proceso completado con tolerancia a errores.")


# COMMAND ----------



# COMMAND ----------

# Contar registros en la tabla Delta
df_secop = spark.table("main.diplomado_datos.secop")
total_registros = df_secop.count()

print(f"🔎 Total de registros en 'main.diplomado_datos.secop': {total_registros:,}")


# COMMAND ----------

# Mostrar primeras filas
display(df_secop.limit(10))
