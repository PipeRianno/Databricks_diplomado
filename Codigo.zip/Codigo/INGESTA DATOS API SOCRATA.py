# Databricks notebook source
token = dbutils.widgets.get("Token_app")
print(token)

# COMMAND ----------

#!/usr/bin/env python

# make sure to install these packages before running:
# pip install pandas
# pip install sodapy

import pandas as pd
from sodapy import Socrata

# Unauthenticated client only works with public data sets. Note 'None'
# in place of application token, and no username or password:
## client = Socrata("www.datos.gov.co", None)

# Example authenticated client (needed for non-public datasets):
client = Socrata("www.datos.gov.co", 
                  'bKEa57kL3xKPUbu9OduvCFUkL')
          


# First 2000 results, returned as JSON from API / converted to Python list of
# dictionaries by sodapy.
## results = client.get("rpmr-utcd", limit=2000)

query="""
Select numero_del_contrato,numero_de_proceso
limit 30000000
"""

# Convert to pandas DataFrame
results_df = pd.DataFrame.from_records(results)
results = client.get("rpmr-utcd", query= query)
 

# COMMAND ----------

results_df = spark.createDataFrame(results)

print(results_df.schema)
 