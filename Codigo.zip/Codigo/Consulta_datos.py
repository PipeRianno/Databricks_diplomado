# Databricks notebook source
# MAGIC %sql
# MAGIC SELECT
# MAGIC   nombre_de_la_entidad,
# MAGIC   departamento_entidad,
# MAGIC   estado_del_proceso,
# MAGIC   valor_contrato
# MAGIC FROM
# MAGIC   main.diplomado_datos.secop
# MAGIC ORDER BY
# MAGIC   CAST(valor_contrato AS DOUBLE) DESC
# MAGIC LIMIT 10;