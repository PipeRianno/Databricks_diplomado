# Databricks notebook source
import requests
import pandas as pd
from io import StringIO
from pyspark.sql import SparkSession
from pyspark.sql.functions import col

# Inicializar Spark
spark = SparkSession.builder.getOrCreate()

# Configuración
base_url = "https://www.datos.gov.co/resource/rpmr-utcd.csv"
limit = 100000
total_registros = 16000000
max_iter = total_registros // limit

# Obtener esquema de la tabla destino
target_schema = spark.table("main.diplomado_datos.secop").schema

# Descarga por lotes
for i in range(max_iter):
    offset = i * limit
    print(f"⏳ Iteración {i+1}/{max_iter} — Offset: {offset}")

    url = f"{base_url}?$limit={limit}&$offset={offset}"
    response = requests.get(url)

    if response.status_code != 200:
        print(f"❌ Error al descargar en offset {offset}. Código: {response.status_code}")
        break

    if len(response.text.strip()) == 0:
        print("✅ No hay más datos disponibles.")
        break

    # ✅ Corrección aquí: forzar todas las columnas a tipo texto
    df_pd = pd.read_csv(StringIO(response.text), delimiter=",", header=0, dtype=str, low_memory=False)

    if df_pd.empty:
        print("✅ Descarga terminada: datos vacíos.")
        break

    # Convertir a Spark y alinear tipos con el esquema destino
    df_spark = spark.createDataFrame(df_pd)
    df_aligned = df_spark.select(
        [col(field.name).cast(field.dataType) for field in target_schema.fields if field.name in df_spark.columns]
    )

    # Guardar lote en tabla Delta
    df_aligned.write.format("delta") \
        .mode("append") \
        .option("mergeSchema", "true") \
        .saveAsTable("main.diplomado_datos.secop")

    print(f"✅ Guardados {df_pd.shape[0]} registros. Total acumulado: {(i+1)*limit}")

print("🎉 Proceso completado.")


# COMMAND ----------

# Contar registros en la tabla Delta
df_secop = spark.table("main.diplomado_datos.secop")
total_registros = df_secop.count()

print(f"🔎 Total de registros en 'main.diplomado_datos.secop': {total_registros:,}")